This project is the Roboc project from OpenClassRoom :
http://exercices.openclassrooms.com/assessment/159?id=235344&slug=apprenez-a-programmer-en-python&login=8434093&tk=fa72e3242f7c7cdeab10cc9e2672bb0b&sbd=2016-02-01&sbdtk=fa78d6dd3126b956265a25af9b322d55

This project has been developped under Python2.7

RUN Roboc.py to test my project 

Developped by atastet@student.42.fr